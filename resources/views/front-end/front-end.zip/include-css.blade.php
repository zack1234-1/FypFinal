 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
 <script src="{{ asset('assets/front-end/assets/js/loopple/kit.fontawesome.js') }}" crossorigin="anonymous"></script>
 <link href="{{ asset('assets/front-end/assets/css/nucleo-icons.css') }}" rel="stylesheet" />
 <link href="{{ asset('assets/front-end/assets/css/nucleo-svg.css') }}" rel="stylesheet" />
 <link rel="stylesheet" href="{{ asset('assets/front-end/assets/css/theme.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/front-end/assets/css/loopple/loopple.css') }}">
 <link rel="stylesheet" href="{{ asset('assets/front-end/assets/css/custom.css') }}">
 <link href="{{ asset('assets/css/toastr.min.css') }}" rel="stylesheet" />
